import pandas as pd
from datetime import datetime
from datetime import timedelta
import warnings
import time
import arxiv
import sqlite3
import unidecode
import pickle

def get_authors_FLast_arxivapi(authors):
    r = []
    for authorv in authors:
        author = authorv.split(' ')
        r.append(unidecode.unidecode(author[0][0]+author[-1]))    
    return ' '.join(r)

def get_authors_FdotLastcomma(authors):
    r = []
    for author in authors:
        authorv = author.split(' ')
        r.append(unidecode.unidecode(' '.join([x[0]+'.' for x in authorv[0:-1]])+' '+authorv[-1]))
    return ', '.join(r)

def progress_bar(relevance):
    s = 100-int(100-100*relevance/5)
    if s > 14:
        if s > 17:
            color = 'red'
        else:
            color = 'orange'
    else:
        color = 'yellow'
    return '|<font color="'+color+'">'+'█'*s+'</font>'+'-'*(20-s)+'|'

categories = {'cond-mat', 'cond-mat.mes-hall', 'quant-ph', 'cond-mat.supr-con', 'cond-mat.mtrl-sci', 'cond-mat.str-el', 'cond-mat.other'}

output = ['html'] # 'html' and/or 'db'

filename = 'data/model.sav'
pipeline = pickle.load(open(filename, 'rb'))

days = 7
delta = timedelta(days = days)
catstr = '+OR+'.join(['cat:'+x for x in categories])
client = arxiv.Client()
nquery = 500
startquery = 0
lastquery = nquery
latestdate = False
predicted_df = pd.DataFrame(columns = ['id','published','authors_FdotLastcomma','authors_FLast', 'title', 'abstract'])

while lastquery == nquery:
    feedparser = client._parse_feed(url='http://export.arxiv.org/api/query?search_query='+catstr+'&start='+str(startquery)+'&max_results='+str(nquery)+'&sortBy=submittedDate')
    if len(feedparser.entries) == 0:
        warnings.warn("Warning...........arXiv api provides 0 entry")
    lastquery = 0
    for entry in feedparser.entries:
        if not(latestdate): latestdate = datetime.strptime(entry.published[0:10],'%Y-%m-%d')
        if latestdate - datetime.strptime(entry.published[0:10],'%Y-%m-%d') < delta:
            lastquery += 1
            predicted_df = predicted_df.append({
                'id' : entry.id,
                'authors_FdotLastcomma' : get_authors_FdotLastcomma([author['name'] for author in entry.authors]),
                'authors_FLast' : get_authors_FLast_arxivapi([author['name'] for author in entry.authors]),
                'title' : entry.title.rstrip(),
                'abstract' : entry.summary.rstrip(),
                'published': datetime.strptime(entry.published[0:10],'%Y-%m-%d')
                            }, ignore_index = True)
    startquery += nquery
    time.sleep(5)

Xnew = predicted_df[['authors_FLast','title','abstract']]

predicted_df['relevance'] = [x[1] for x in pipeline.predict_proba(Xnew)]

if 'db' in output:
    tosql_df = predicted_df[['id','published','authors_FdotLastcomma','title','abstract','relevance']].rename(columns = {"authors_FdotLastcomma": "authors"})

    conn = sqlite3.connect('data/manuscripts.db')
    c = conn.cursor()

    c.execute('CREATE TABLE IF NOT EXISTS manuscripts (id, published, authors, title, abstract, relevance)')
    conn.commit()
    tosql_df.to_sql('manuscripts', conn, if_exists = 'replace', index = False)

if 'html' in output:
    tohtml_df = predicted_df[['id','published','authors_FdotLastcomma','title','abstract','relevance']].rename(columns = {"authors_FdotLastcomma": "authors"})

    day = False
    html = '<ul>\n'
    html += '<hr>\n'
    for idx, row in tohtml_df[tohtml_df['relevance']>0.5].sort_values(by=['published','relevance'],ascending=False).iterrows():
        if day != row['published']:
            html += '<div class="date">'+row['published'].strftime('%-d %B, %Y')+'</div>\n'
            html += '<hr>\n'
            day = row['published']
        html += '<li>\n'
        html += '<a href="'+row['id']+'">arXiv:'+row['id'].split('http://arxiv.org/abs/')[-1][:-2]+'</a>\n'
        html += '<div class="relevance"><b>Relevance:</b>'
        html += '<font style="font-family:courier, monospace">'+progress_bar(row['relevance'])+'</font>'
        html += str(round(100*row['relevance'],1))+'%</div>\n'
        html += '<div class="title"><b>Title:</b> '+row['title']+'</div>\n'
        html += '<div class="authors_head"><b>Authors:</div></b> '
        html += '<div class="authors"><i>'+row['authors']+'</i></div>\n'
        html += '<div class="abstract_head"><b>Abstract:</b></div>\n'
        html += '<div class="abstract">'+row['abstract']+'</div>\n'
        html += '<br>\n'
        html += '</li>\n'
        html += '<hr>\n'
    html += '</ul>'

    with open("data/template.html", "r") as file:
        template = file.read()

    html = template.replace("***", html)

    with open("data/manuscripts.html", "w") as file:
            file.write(html)